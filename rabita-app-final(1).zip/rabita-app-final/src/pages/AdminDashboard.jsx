import { useState } from "react";
import TopBar from "../components/TopBar";
import AdminStudents from "../components/admin/AdminStudents";
import AdminMeetings from "../components/admin/AdminMeetings";
import AdminAttendance from "../components/admin/AdminAttendance";
import AdminPayments from "../components/admin/AdminPayments";

const TABS = [
  { key: "students", label: "الطلاب", Comp: AdminStudents },
  { key: "meetings", label: "اللقاءات", Comp: AdminMeetings },
  { key: "attendance", label: "الحضور والغياب", Comp: AdminAttendance },
  { key: "payments", label: "العشور", Comp: AdminPayments },
];

export default function AdminDashboard() {
  const [tab, setTab] = useState("students");
  const Active = TABS.find((t) => t.key === tab).Comp;

  return (
    <div className="min-h-screen bg-sand-50">
      <TopBar title="لوحة الأدمن" />

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-4 py-2 rounded-xl font-body font-semibold text-sm whitespace-nowrap transition ${
                tab === t.key
                  ? "bg-teal-900 text-sand-50"
                  : "bg-white text-ink/60 border border-ink/10 hover:border-teal-900/30"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <Active />
      </div>
    </div>
  );
}
