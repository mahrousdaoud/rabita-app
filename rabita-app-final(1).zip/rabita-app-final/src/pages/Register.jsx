import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { user, completeRegistration } = useAuth();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: user?.displayName || "",
    phone: "",
    region: "",
    team: "",
    age: "",
    memberType: "",
  });

  const update = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.memberType) return;
    setSaving(true);
    try {
      await completeRegistration(form);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-sand-50 py-10 px-4">
      <div className="max-w-lg mx-auto">
        <div className="text-center mb-8">
          <img src="/rabita-icon.svg" alt="الشعار" className="w-16 h-16 mx-auto mb-3" />
          <h1 className="font-display font-bold text-xl text-teal-950">استمارة بيانات الخدمة</h1>
          <p className="font-body text-sm text-ink/60 mt-1">
            مرحبًا بيك {user?.displayName} — كمّل بياناتك عشان نضمك للرابطة
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-6 space-y-5">
          {/* جديد أو قديم */}
          <div>
            <label className="font-body text-sm font-semibold text-ink block mb-2">إنت تبع المدرسة الجديدة ولا القديمة؟</label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { v: "new", label: "مدرسة جديدة" },
                { v: "old", label: "مدرسة قديمة" },
              ].map((opt) => (
                <button
                  type="button"
                  key={opt.v}
                  onClick={() => setForm((f) => ({ ...f, memberType: opt.v }))}
                  className={`py-3 rounded-xl font-body font-medium border transition ${
                    form.memberType === opt.v
                      ? "bg-teal-900 text-sand-50 border-teal-900"
                      : "bg-sand-50 text-ink border-ink/10 hover:border-teal-900/40"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <Field label="الاسم بالكامل" value={form.name} onChange={update("name")} required />
          <Field label="رقم الموبايل" value={form.phone} onChange={update("phone")} required type="tel" />
          <Field label="المنطقة" value={form.region} onChange={update("region")} required placeholder="مثال: المعادي، شبرا، فيصل..." />
          <Field label="اسم الفريق" value={form.team} onChange={update("team")} required placeholder="اسم فريق الخدمة بالرياضة" />
          <Field label="السن" value={form.age} onChange={update("age")} required type="number" min="4" max="99" />

          <button
            type="submit"
            disabled={saving || !form.memberType}
            className="w-full bg-gold-500 hover:bg-gold-600 disabled:opacity-50 transition
                       text-teal-950 font-body font-bold py-3.5 rounded-xl2 mt-2"
          >
            {saving ? "جاري الحفظ..." : "تسجيل واستكمال الدخول"}
          </button>
        </form>
      </div>
    </div>
  );
}

function Field({ label, ...props }) {
  return (
    <div>
      <label className="font-body text-sm font-semibold text-ink block mb-1.5">{label}</label>
      <input
        {...props}
        className="w-full border border-ink/15 rounded-xl px-4 py-2.5 font-body text-ink
                   focus:outline-none focus:ring-2 focus:ring-teal-700/40 focus:border-teal-700"
      />
    </div>
  );
}
