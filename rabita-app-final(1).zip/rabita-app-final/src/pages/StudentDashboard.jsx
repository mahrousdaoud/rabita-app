import { useEffect, useMemo, useState } from "react";
import { collection, query, where, orderBy, onSnapshot } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../context/AuthContext";
import TopBar from "../components/TopBar";

function monthsBetween(startDate, endDate) {
  if (!startDate) return 0;
  const s = startDate.toDate ? startDate.toDate() : new Date(startDate);
  let months = (endDate.getFullYear() - s.getFullYear()) * 12 + (endDate.getMonth() - s.getMonth());
  return Math.max(months, 0);
}

export default function StudentDashboard() {
  const { user, profile } = useAuth();
  const [meetings, setMeetings] = useState([]);
  const [attendance, setAttendance] = useState([]);

  useEffect(() => {
    const now = new Date();
    const qMeetings = query(
      collection(db, "meetings"),
      where("date", ">=", now),
      orderBy("date", "asc")
    );
    const unsub = onSnapshot(qMeetings, (snap) => {
      setMeetings(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!user) return;
    const qAtt = query(collection(db, "attendanceRecords"), where("studentId", "==", user.uid));
    const unsub = onSnapshot(qAtt, (snap) => {
      setAttendance(snap.docs.map((d) => d.data()));
    });
    return unsub;
  }, [user]);

  const presentCount = attendance.filter((a) => a.present).length;
  const absentCount = attendance.filter((a) => !a.present).length;

  const monthsSinceJoin = useMemo(
    () => monthsBetween(profile?.createdAt, new Date()) || 1,
    [profile]
  );
  const paidCount = profile?.paidMonths?.length || 0;
  const remainingMonths = Math.max(monthsSinceJoin - paidCount, 0);

  return (
    <div className="min-h-screen bg-sand-50">
      <TopBar title="لوحتي" />

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* بطاقة البيانات */}
        <div className="bg-teal-900 text-sand-50 rounded-xl2 p-5 flex items-center gap-4">
          {profile?.photoURL && (
            <img src={profile.photoURL} className="w-14 h-14 rounded-full border-2 border-gold-500" alt="" />
          )}
          <div>
            <p className="font-display font-bold text-lg">{profile?.name}</p>
            <p className="font-body text-teal-100/70 text-sm">
              فريق {profile?.team} · منطقة {profile?.region} · {profile?.age} سنة
            </p>
            <span className="inline-block mt-1 text-xs font-body px-2 py-0.5 rounded-full bg-gold-500/20 text-gold-400">
              {profile?.memberType === "new" ? "مدرسة جديدة" : "مدرسة قديمة"}
            </span>
          </div>
        </div>

        {/* الحضور والغياب */}
        <div className="grid grid-cols-2 gap-4">
          <StatCard label="عدد مرات الحضور" value={presentCount} tone="good" />
          <StatCard label="عدد مرات الغياب" value={absentCount} tone="bad" />
        </div>

        {/* العشور */}
        <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5">
          <h2 className="font-display font-bold text-teal-950 mb-3">حساب العشور</h2>
          <div className="flex justify-between text-sm font-body mb-2">
            <span className="text-ink/60">شهور تم دفعها</span>
            <span className="font-bold text-good">{paidCount}</span>
          </div>
          <div className="flex justify-between text-sm font-body">
            <span className="text-ink/60">باقي عليك</span>
            <span className="font-bold text-bad">{remainingMonths} شهر</span>
          </div>
          <div className="w-full bg-sand-100 rounded-full h-2 mt-4 overflow-hidden">
            <div
              className="bg-gold-500 h-2 rounded-full"
              style={{ width: `${monthsSinceJoin ? (paidCount / monthsSinceJoin) * 100 : 0}%` }}
            />
          </div>
        </div>

        {/* اللقاءات الجاية */}
        <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5">
          <h2 className="font-display font-bold text-teal-950 mb-3">مواعيد اللقاءات الجاية</h2>
          {meetings.length === 0 && (
            <p className="text-ink/50 font-body text-sm">مفيش لقاءات مجدولة دلوقتي</p>
          )}
          <ul className="space-y-3">
            {meetings.map((m) => (
              <li key={m.id} className="flex items-center justify-between border-b border-ink/5 pb-3 last:border-0 last:pb-0">
                <div>
                  <p className="font-body font-semibold text-ink">{m.title}</p>
                  {m.notes && <p className="text-xs text-ink/50 font-body">{m.notes}</p>}
                </div>
                <span className="font-body text-sm text-teal-800 font-medium">
                  {m.date?.toDate?.().toLocaleDateString("ar-EG", { weekday: "short", day: "numeric", month: "short" })}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, tone }) {
  const color = tone === "good" ? "text-good" : "text-bad";
  return (
    <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5 text-center">
      <p className={`font-display font-extrabold text-3xl ${color}`}>{value}</p>
      <p className="font-body text-ink/60 text-sm mt-1">{label}</p>
    </div>
  );
}
