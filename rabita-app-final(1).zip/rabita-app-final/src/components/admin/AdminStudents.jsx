import { useEffect, useState } from "react";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "../../lib/firebase";

export default function AdminStudents() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const q = query(collection(db, "students"), orderBy("name", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setStudents(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, []);

  const filtered = students.filter((s) =>
    `${s.name} ${s.team} ${s.region}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <input
        placeholder="دور بالاسم أو الفريق أو المنطقة..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full border border-ink/15 rounded-xl px-4 py-2.5 font-body mb-4 focus:outline-none focus:ring-2 focus:ring-teal-700/40"
      />

      <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 overflow-hidden">
        <table className="w-full text-sm font-body">
          <thead className="bg-sand-100 text-ink/60">
            <tr>
              <th className="text-right px-4 py-2.5">الاسم</th>
              <th className="text-right px-4 py-2.5">الفريق</th>
              <th className="text-right px-4 py-2.5">المنطقة</th>
              <th className="text-right px-4 py-2.5">السن</th>
              <th className="text-right px-4 py-2.5">النوع</th>
              <th className="text-right px-4 py-2.5">الهاتف</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => (
              <tr key={s.id} className="border-t border-ink/5">
                <td className="px-4 py-2.5 font-medium text-ink">{s.name}</td>
                <td className="px-4 py-2.5 text-ink/70">{s.team}</td>
                <td className="px-4 py-2.5 text-ink/70">{s.region}</td>
                <td className="px-4 py-2.5 text-ink/70">{s.age}</td>
                <td className="px-4 py-2.5 text-ink/70">{s.memberType === "new" ? "جديد" : "قديم"}</td>
                <td className="px-4 py-2.5 text-ink/70">{s.phone}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-6 text-center text-ink/40">لا يوجد طلاب مطابقين</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
