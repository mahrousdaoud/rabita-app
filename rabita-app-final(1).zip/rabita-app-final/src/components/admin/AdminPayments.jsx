import { useEffect, useState } from "react";
import { collection, doc, onSnapshot, orderBy, query, updateDoc } from "firebase/firestore";
import { db } from "../../lib/firebase";

function monthKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthsSince(startDate) {
  if (!startDate) return [];
  const start = startDate.toDate ? startDate.toDate() : new Date(startDate);
  const now = new Date();
  const list = [];
  let cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cursor <= now) {
    list.push(monthKey(cursor));
    cursor = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
  }
  return list;
}

export default function AdminPayments() {
  const [students, setStudents] = useState([]);
  const [selectedId, setSelectedId] = useState("");

  useEffect(() => {
    const q = query(collection(db, "students"), orderBy("name", "asc"));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setStudents(list);
      if (!selectedId && list.length) setSelectedId(list[0].id);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = students.find((s) => s.id === selectedId);
  const months = selected ? monthsSince(selected.createdAt) : [];
  const paid = new Set(selected?.paidMonths || []);

  const toggleMonth = async (m) => {
    if (!selected) return;
    const current = new Set(selected.paidMonths || []);
    current.has(m) ? current.delete(m) : current.add(m);
    await updateDoc(doc(db, "students", selected.id), { paidMonths: Array.from(current) });
  };

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-4 h-fit">
        <h3 className="font-display font-bold text-teal-950 mb-3 text-sm">الطلاب</h3>
        <ul className="space-y-1 max-h-96 overflow-y-auto">
          {students.map((s) => (
            <li key={s.id}>
              <button
                onClick={() => setSelectedId(s.id)}
                className={`w-full text-right px-3 py-2 rounded-lg text-sm font-body ${
                  selectedId === s.id ? "bg-teal-900 text-sand-50" : "hover:bg-sand-100 text-ink"
                }`}
              >
                {s.name}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div className="md:col-span-2 bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5">
        {selected ? (
          <>
            <h3 className="font-display font-bold text-teal-950 mb-1">{selected.name}</h3>
            <p className="text-xs text-ink/50 font-body mb-4">
              مدفوع {paid.size} من {months.length} شهر
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {months.map((m) => (
                <button
                  key={m}
                  onClick={() => toggleMonth(m)}
                  className={`px-2 py-2.5 rounded-lg text-xs font-body font-semibold border ${
                    paid.has(m)
                      ? "bg-good/10 border-good text-good"
                      : "bg-bad/5 border-bad/30 text-bad"
                  }`}
                >
                  {m}
                </button>
              ))}
              {months.length === 0 && (
                <p className="text-ink/40 text-sm font-body col-span-full">لا توجد شهور مستحقة بعد</p>
              )}
            </div>
          </>
        ) : (
          <p className="text-ink/40 font-body">اختر طالب من القائمة</p>
        )}
      </div>
    </div>
  );
}
