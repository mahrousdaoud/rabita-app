import { useEffect, useState } from "react";
import { collection, addDoc, deleteDoc, doc, onSnapshot, orderBy, query, Timestamp } from "firebase/firestore";
import { db } from "../../lib/firebase";

export default function AdminMeetings() {
  const [meetings, setMeetings] = useState([]);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    const q = query(collection(db, "meetings"), orderBy("date", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setMeetings(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, []);

  const addMeeting = async (e) => {
    e.preventDefault();
    if (!title || !date) return;
    await addDoc(collection(db, "meetings"), {
      title,
      notes,
      date: Timestamp.fromDate(new Date(date)),
    });
    setTitle("");
    setDate("");
    setNotes("");
  };

  const removeMeeting = async (id) => {
    if (confirm("متأكد إنك عايز تمسح اللقاء ده؟")) {
      await deleteDoc(doc(db, "meetings", id));
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <form onSubmit={addMeeting} className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5 space-y-3 h-fit">
        <h3 className="font-display font-bold text-teal-950">إضافة لقاء جديد</h3>
        <input
          placeholder="عنوان اللقاء"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border border-ink/15 rounded-xl px-4 py-2.5 font-body focus:outline-none focus:ring-2 focus:ring-teal-700/40"
        />
        <input
          type="datetime-local"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="w-full border border-ink/15 rounded-xl px-4 py-2.5 font-body focus:outline-none focus:ring-2 focus:ring-teal-700/40"
        />
        <input
          placeholder="ملاحظات (اختياري)"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full border border-ink/15 rounded-xl px-4 py-2.5 font-body focus:outline-none focus:ring-2 focus:ring-teal-700/40"
        />
        <button className="w-full bg-teal-900 text-sand-50 font-body font-semibold py-2.5 rounded-xl">
          إضافة اللقاء
        </button>
      </form>

      <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 p-5">
        <h3 className="font-display font-bold text-teal-950 mb-3">كل اللقاءات</h3>
        <ul className="space-y-2 max-h-96 overflow-y-auto">
          {meetings.map((m) => (
            <li key={m.id} className="flex justify-between items-center border-b border-ink/5 pb-2">
              <div>
                <p className="font-body font-medium text-ink">{m.title}</p>
                <p className="text-xs text-ink/50 font-body">
                  {m.date?.toDate?.().toLocaleString("ar-EG")}
                </p>
              </div>
              <button onClick={() => removeMeeting(m.id)} className="text-bad text-xs font-body">
                حذف
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
