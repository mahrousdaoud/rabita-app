import { useEffect, useState } from "react";
import { collection, doc, onSnapshot, orderBy, query, setDoc } from "firebase/firestore";
import { db } from "../../lib/firebase";

export default function AdminAttendance() {
  const [meetings, setMeetings] = useState([]);
  const [students, setStudents] = useState([]);
  const [records, setRecords] = useState({});
  const [meetingId, setMeetingId] = useState("");

  useEffect(() => {
    const q = query(collection(db, "meetings"), orderBy("date", "desc"));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setMeetings(list);
      if (!meetingId && list.length) setMeetingId(list[0].id);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const q = query(collection(db, "students"), orderBy("name", "asc"));
    return onSnapshot(q, (snap) => setStudents(snap.docs.map((d) => ({ id: d.id, ...d.data() }))));
  }, []);

  useEffect(() => {
    if (!meetingId) return;
    const q = query(collection(db, "attendanceRecords"));
    return onSnapshot(q, (snap) => {
      const map = {};
      snap.docs.forEach((d) => {
        const data = d.data();
        if (data.meetingId === meetingId) map[data.studentId] = data.present;
      });
      setRecords(map);
    });
  }, [meetingId]);

  const toggle = async (studentId, present) => {
    await setDoc(doc(db, "attendanceRecords", `${meetingId}_${studentId}`), {
      meetingId,
      studentId,
      present,
    });
  };

  return (
    <div>
      <div className="mb-4">
        <label className="font-body text-sm font-semibold text-ink block mb-1.5">اختر اللقاء</label>
        <select
          value={meetingId}
          onChange={(e) => setMeetingId(e.target.value)}
          className="w-full md:w-96 border border-ink/15 rounded-xl px-4 py-2.5 font-body focus:outline-none focus:ring-2 focus:ring-teal-700/40"
        >
          {meetings.map((m) => (
            <option key={m.id} value={m.id}>
              {m.title} — {m.date?.toDate?.().toLocaleDateString("ar-EG")}
            </option>
          ))}
        </select>
      </div>

      <div className="bg-white rounded-xl2 shadow-sm border border-teal-900/5 overflow-hidden">
        <table className="w-full text-sm font-body">
          <thead className="bg-sand-100 text-ink/60">
            <tr>
              <th className="text-right px-4 py-2.5">الاسم</th>
              <th className="text-right px-4 py-2.5">الفريق</th>
              <th className="text-right px-4 py-2.5">الحالة</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => {
              const present = records[s.id];
              return (
                <tr key={s.id} className="border-t border-ink/5">
                  <td className="px-4 py-2.5 font-medium text-ink">{s.name}</td>
                  <td className="px-4 py-2.5 text-ink/70">{s.team}</td>
                  <td className="px-4 py-2.5">
                    <div className="inline-flex rounded-lg overflow-hidden border border-ink/10">
                      <button
                        onClick={() => toggle(s.id, true)}
                        className={`px-3 py-1.5 text-xs font-semibold ${
                          present === true ? "bg-good text-white" : "bg-white text-ink/50"
                        }`}
                      >
                        حاضر
                      </button>
                      <button
                        onClick={() => toggle(s.id, false)}
                        className={`px-3 py-1.5 text-xs font-semibold ${
                          present === false ? "bg-bad text-white" : "bg-white text-ink/50"
                        }`}
                      >
                        غايب
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
