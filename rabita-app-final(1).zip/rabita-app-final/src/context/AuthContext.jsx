import { createContext, useContext, useEffect, useState } from "react";
import {
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, googleProvider, db, isAdminEmail } from "../lib/firebase";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);       // Firebase auth user
  const [profile, setProfile] = useState(null);  // Firestore student doc (or null if not registered yet)
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setUser(fbUser);
      if (fbUser) {
        const ref = doc(db, "students", fbUser.uid);
        const snap = await getDoc(ref);
        setProfile(snap.exists() ? snap.data() : null);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const signInWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
  };

  // يُستدعى بعد ما الطالب يملأ استمارة التسجيل أول مرة
  const completeRegistration = async (formData) => {
    if (!user) return;
    const ref = doc(db, "students", user.uid);
    const data = {
      name: formData.name,
      email: user.email,
      photoURL: user.photoURL || "",
      phone: formData.phone,
      region: formData.region,
      team: formData.team,
      age: Number(formData.age),
      memberType: formData.memberType, // "new" | "old"
      isAdmin: isAdminEmail(user.email),
      paidMonths: [],
      createdAt: serverTimestamp(),
    };
    await setDoc(ref, data);
    setProfile(data);
  };

  const value = {
    user,
    profile,
    loading,
    isAdmin: !!user && isAdminEmail(user.email),
    signInWithGoogle,
    signOut,
    completeRegistration,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
